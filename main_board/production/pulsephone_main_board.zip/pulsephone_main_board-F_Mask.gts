G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.6*
G04 #@! TF.CreationDate,2026-01-20T16:51:14-05:00*
G04 #@! TF.ProjectId,pulsephone_main_board,70756c73-6570-4686-9f6e-655f6d61696e,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.6) date 2026-01-20 16:51:14*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 APERTURE END LIST*
M02*
